//
//  BMI.swift
//  BMI Calculator
//
//  Created by MacBook on 9/8/20.
//  Copyright © 2020 Angela Yu. All rights reserved.
//

import UIKit

struct BMI {
    let value : Double
    let advice : String
    let color : UIColor
}
