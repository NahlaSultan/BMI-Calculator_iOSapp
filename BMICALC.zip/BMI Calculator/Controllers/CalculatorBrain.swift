//
//  CalculatorBrain.swift
//  BMI Calculator
//
//  Created by MacBook on 9/7/20.
//  Copyright © 2020 Angela Yu. All rights reserved.
//

import UIKit

struct CalculatorBrain {
    var bmi : BMI?
    
    
    mutating func calculateBMI(weight: Int, height: Double) {
        let bmiVal = Double(weight) / (height*height)

        if bmiVal<18.5{
            bmi = BMI(value: bmiVal, advice: "eat more pies", color: #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1))
        }
        else if bmiVal<24.9{
            bmi = BMI(value: bmiVal, advice: "look at you!", color: #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1))
        }else{
            bmi = BMI(value: bmiVal, advice: "eat less, dude!", color: #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1))
        }
      
    }
    
    func getBMI()->String{
        return String(format: "%.1f", bmi?.value ?? 0.0)
    }
    func getAdvice()->String{
        return bmi?.advice ?? "no advice"
       }
    
    func getColor()->UIColor{
        return bmi?.color ?? #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    }
}
